<nav class="navbar navbar-light bg-white">

    <a href="/src/resources/views/" class="navbar-brand">
        <h4 class="d-flex align-items-center">
            <img src="../../../public/assets/icon.svg" alt="">
             <span class="ml-2">Gorum</span>
        </h4>
    </a>

    <a href="auth" id="auth-nav" class="color-primary ml-auto mr-3">Login / Register?</a>

        <div class="input-group" style="width: auto !important">
            <input type="text" id="filter-post" class="form-control" aria-label="Recipient's username" placeholder="Search anything..." aria-describedby="button-addon2" name="q">

            <div class="input-group-append">
                <button class="btn btn-outline-primary" type="button" id="button-addon2">
                    <i class="fa fa-search"></i>
                </button>
            </div>
        </div>

</nav>