export const BASE_API_URL = 'localhost:8000'
export const BASE_API_URL_SOCKET = 'localhost:8090'
export const ROOT_URL = document.location.hostname