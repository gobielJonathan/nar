<?php
namespace Database\Seed;

interface Seed{

    public function seed();
}