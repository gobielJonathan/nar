<?php

namespace Database\Migration;

abstract class Migrater
{
    abstract public function query();

}
